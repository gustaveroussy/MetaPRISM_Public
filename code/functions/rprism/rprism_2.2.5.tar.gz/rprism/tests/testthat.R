library(testthat)
library(rprism)

test_check("rprism")
