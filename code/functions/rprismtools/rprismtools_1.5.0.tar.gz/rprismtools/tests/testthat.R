library(testthat)
library(rprismtools)

test_check("rprismtools")
