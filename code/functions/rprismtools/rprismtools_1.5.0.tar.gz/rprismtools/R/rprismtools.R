#' rprismtools: A package with util functions.
#'
#' 'rprismtools' provides small functions useful for making plots, for rendering html widgets or for performing common
#' tasks.
#'
#' @docType package
#' @author Yoann Pradat
#' @name rprismtools 
NULL
